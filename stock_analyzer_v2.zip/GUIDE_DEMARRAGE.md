# 🚀 Guide de Démarrage Rapide

## Installation en 3 étapes

### 1️⃣ Extraire les fichiers
Décompressez le fichier `stock_analyzer_multipage.zip` dans le dossier de votre choix.

### 2️⃣ Installer les dépendances
Ouvrez un terminal dans le dossier `stock_analyzer` et exécutez :

```bash
pip install -r requirements.txt
```

### 3️⃣ Lancer l'application
```bash
streamlit run Home.py
```

L'application s'ouvrira automatiquement dans votre navigateur à l'adresse : `http://localhost:8501`

---

## 🎮 Navigation

### Barre Latérale (Sidebar)
- **🏠 Home** : Analyse individuelle d'une action
- **📊 Classements** : Voir les tops et rankings

### Pages Disponibles

#### 🏠 Page d'Accueil
**Fonctionnalités :**
- Recherche d'entreprise avec autocomplétion
- Analyse complète avec score global
- Graphiques de prix interactifs
- Indicateurs techniques détaillés
- Recommandation d'achat/vente

**Comment utiliser :**
1. Tapez le nom d'une entreprise (ex: "Apple", "Tesla")
2. Choisissez votre horizon d'investissement
3. Cliquez sur "🚀 ANALYSER"

#### 📊 Page Classements
**5 onglets disponibles :**

1. **🏆 Top 100 Capitalisation**
   - Les 100 entreprises les plus valorisées
   - Capitalisation boursière, performances, volumes

2. **📈 Meilleures Performances 1Y**
   - Top 50 des actions qui ont le plus monté
   - Avec médailles pour le top 3 🥇🥈🥉

3. **📉 Pires Performances 1Y**
   - Top 50 des actions qui ont le plus baissé
   - Pour identifier les opportunités ou éviter les risques

4. **💰 Meilleurs Dividendes**
   - Top 50 des rendements de dividende
   - Idéal pour les investisseurs recherchant des revenus passifs

5. **🔥 Plus Gros Volumes**
   - Top 50 des actions les plus échangées
   - Indicateur de liquidité et d'intérêt du marché

---

## 💡 Conseils d'Utilisation

### Pour l'Analyse Individuelle
- ✅ Utilisez le nom complet de l'entreprise pour une recherche plus précise
- ✅ Les tickers fonctionnent aussi (AAPL, MSFT, TSLA, etc.)
- ✅ Cliquez sur "ℹ️ Détails du calcul" sous chaque indicateur pour comprendre la méthodologie
- ✅ Changez la période du graphique avec les boutons 1M, 3M, 6M, 1A, etc.

### Pour les Classements
- ✅ Cliquez sur "🔄 Actualiser les données" pour obtenir les données les plus récentes
- ✅ Les données sont mises en cache pendant 5 minutes pour des performances optimales
- ✅ Parcourez les différents onglets pour avoir une vue d'ensemble du marché
- ✅ Les couleurs indiquent la performance :
  - 🟢 Vert = Performance positive
  - 🔴 Rouge = Performance négative

---

## 🌍 Marchés Couverts

L'application couvre les principales actions de :
- 🇺🇸 **États-Unis** : AAPL, MSFT, GOOGL, TSLA, NVDA, etc.
- 🇪🇺 **Europe** : LVMH, Airbus, SAP, L'Oréal, etc.
- 🇯🇵 **Japon** : Toyota, Sony, SoftBank, Nintendo, etc.
- 🌏 **Asie** : TSMC, Alibaba, Samsung, Tencent, etc.

---

## ❓ Résolution de Problèmes

### L'application ne démarre pas
```bash
# Vérifiez que vous êtes dans le bon dossier
cd stock_analyzer

# Vérifiez l'installation des dépendances
pip list | grep streamlit
```

### Erreur "Module not found"
```bash
# Réinstallez les dépendances
pip install -r requirements.txt --upgrade
```

### Les données ne se chargent pas
- ✅ Vérifiez votre connexion internet
- ✅ Attendez quelques secondes (l'API peut être lente)
- ✅ Cliquez sur "🔄 Actualiser les données"

### L'autocomplétion ne fonctionne pas
```bash
# Installation optionnelle de streamlit-searchbox
pip install streamlit-searchbox
```

---

## 🎨 Personnalisation

### Ajouter plus d'actions aux classements

Éditez le fichier `pages/1_📊_Classements.py` :

```python
MAJOR_STOCKS = {
    "🇺🇸 Tech US": ["AAPL", "MSFT", "GOOGL", "VOTRE_TICKER_ICI"],
    # Ajoutez vos tickers préférés ici
}
```

### Modifier les seuils de scoring

Éditez le fichier `Algorithmev1.py` pour ajuster les barèmes de notation.

---

## 📊 Interprétation des Scores

### Score Global (sur 100)
- **80-100** : 🟢 ACHAT FORT - Action très prometteuse
- **65-79** : 🟢 ACHAT - Bonne opportunité
- **50-64** : 🟡 NEUTRE - Attendre de meilleurs signaux
- **35-49** : 🟠 PRUDENCE - Risques présents
- **0-34** : 🔴 ÉVITER - Action à risque élevé

### Indicateurs Individuels (sur 10)
- **8-10** : 🟢 Excellent
- **6-7.9** : 🟢 Bon
- **4-5.9** : 🟡 Moyen
- **2-3.9** : 🟠 Faible
- **0-1.9** : 🔴 Très faible

---

## 🔒 Sécurité et Confidentialité

- ✅ Toutes les données sont publiques (via Yahoo Finance)
- ✅ Aucune donnée personnelle n'est collectée
- ✅ L'application fonctionne localement sur votre ordinateur
- ✅ Aucune connexion à des serveurs tiers (sauf Yahoo Finance API)

---

## ⚠️ Disclaimer Important

**CET OUTIL EST ÉDUCATIF ET NE CONSTITUE PAS UN CONSEIL FINANCIER**

- 📌 Les performances passées ne garantissent pas les résultats futurs
- 📌 Investir en bourse comporte des risques de perte en capital
- 📌 Consultez toujours un conseiller financier avant d'investir
- 📌 L'auteur n'est pas responsable de vos décisions d'investissement

---

## 🆘 Support

**Problème technique ?**
1. Vérifiez que vous avez la dernière version de Python (3.8+)
2. Réinstallez les dépendances
3. Consultez les logs d'erreur dans le terminal

**Suggestions d'amélioration ?**
Contactez @Mathieugird

---

## 📚 Ressources Utiles

- [Documentation Streamlit](https://docs.streamlit.io/)
- [Documentation yfinance](https://pypi.org/project/yfinance/)
- [Yahoo Finance](https://finance.yahoo.com/)

---

**Bon trading ! 📈💰**

Version 1.0 - Novembre 2024
Créé par @Mathieugird
