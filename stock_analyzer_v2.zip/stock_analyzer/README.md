# 📈 Analyseur d'Actions Boursières - Multi-Pages

Application Streamlit multi-pages pour l'analyse d'actions boursières avec des classements style CoinMarketCap.

## 🚀 Structure de l'Application

```
stock_analyzer/
│
├── Home.py                          # 🏠 Page principale - Analyse individuelle
├── pages/
│   └── 1_📊_Classements.py         # 📊 Page des classements (Top 100, performances, etc.)
│
├── Algorithmev1.py                  # Algorithme de scoring des actions
├── smart_search.py                  # Système de recherche intelligente
├── requirements.txt                 # Dépendances Python
└── README.md                        # Ce fichier
```

## 📊 Fonctionnalités

### Page d'Accueil (Home.py)
- ✅ Analyse individuelle d'actions
- ✅ Score global sur 100
- ✅ Recommandation d'achat/vente
- ✅ Graphiques interactifs
- ✅ Indicateurs techniques détaillés
- ✅ Analyse de valorisation

### Page Classements (1_📊_Classements.py)
- 🏆 **Top 100 Capitalisation** - Les entreprises les plus valorisées
- 📈 **Meilleures Performances 1Y** - Top 50 des hausses annuelles
- 📉 **Pires Performances 1Y** - Top 50 des baisses annuelles
- 💰 **Meilleurs Dividendes** - Top 50 des rendements de dividende
- 🔥 **Plus Gros Volumes** - Top 50 des actions les plus échangées

## 🛠️ Installation

1. **Installer les dépendances**
```bash
pip install -r requirements.txt
```

2. **Lancer l'application**
```bash
streamlit run Home.py
```

3. **Navigation**
   - L'application s'ouvrira dans votre navigateur
   - Utilisez la barre latérale pour naviguer entre les pages
   - Page d'accueil : Analyse individuelle
   - Page Classements : Voir les tops et rankings

## 📦 Dépendances

- `streamlit` - Framework web
- `yfinance` - Données boursières en temps réel
- `pandas` - Manipulation de données
- `numpy` - Calculs numériques
- `plotly` - Graphiques interactifs
- `fuzzywuzzy` - Recherche floue
- `python-Levenshtein` - Amélioration de la recherche
- `streamlit-searchbox` - Autocomplétion (optionnel)

## 🎯 Utilisation

### Analyse Individuelle (Page d'accueil)
1. Recherchez une entreprise (ex: "Apple", "Tesla", "NVDA")
2. Sélectionnez l'horizon d'investissement
3. Cliquez sur "🚀 ANALYSER"
4. Consultez le score, les indicateurs et les graphiques

### Classements (Page Classements)
1. Accédez à la page via la barre latérale
2. Choisissez un onglet (Capitalisation, Performances, etc.)
3. Cliquez sur "🔄 Actualiser" pour charger les données
4. Parcourez les classements avec toutes les métriques

## ⚠️ Notes Importantes

- **Cache** : Les données sont mises en cache pendant 5 minutes pour optimiser les performances
- **Rate Limiting** : Un délai est ajouté entre les requêtes pour éviter les limitations de l'API
- **Données** : Les données proviennent de Yahoo Finance via yfinance
- **Disclaimer** : Cet outil est éducatif et ne constitue pas un conseil financier

## 🌍 Couverture des Marchés

L'application couvre les principaux marchés mondiaux :
- 🇺🇸 États-Unis (Tech, Finance, Consommation)
- 🇪🇺 Europe (LVMH, Airbus, SAP, etc.)
- 🇯🇵 Japon (Toyota, Sony, SoftBank, etc.)
- 🌏 Asie-Pacifique (TSMC, Alibaba, Samsung, etc.)

## 🔧 Personnalisation

Vous pouvez facilement ajouter plus d'actions dans la page Classements en modifiant le dictionnaire `MAJOR_STOCKS` dans `pages/1_📊_Classements.py`.

## 📝 Version

**Version 1.0** - Novembre 2024

Créé par @Mathieugird

## 🤝 Support

Pour toute question ou suggestion, utilisez le système de feedback intégré dans l'application.

---

**⚠️ Avertissement Légal**

Cet outil est fourni à des fins éducatives et informatives uniquement. Il ne constitue pas un conseil d'investissement personnel. Les performances passées ne garantissent pas les résultats futurs. Consultez toujours un professionnel qualifié avant de prendre des décisions d'investissement.
